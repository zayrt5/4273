# !/bin/bash

#Id like to think this tests the multi threading ability of the server
#but I have no idea
curl localhost:8888
curl localhost:8888/files/text1.txt
curl localhost:8888/awdsss
curl localhost:8888/images/wine3.jpg
curl localhost:8888/images/exam.gif
